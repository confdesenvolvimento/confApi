# Testes do ConfApi rodoviário no Postman

Importe a collection e o environment JSON desta pasta. Selecione o environment antes de enviar requisições. O guia PDF está em `../../output/pdf/guia-testes-confapi-rodoviario-postman.pdf` no repositório e na raiz do pacote ZIP.

1. Ajuste baseUrl (padrão http://localhost:8088, sem barra final) e o contexto do WAR, quando houver.
2. Preencha appToken com um JWT aceito pelo ConfApi, sem Bearer. /user/auth também está protegido na configuração atual: a primeira chamada da collection apenas renova um acesso já autenticado. Para o primeiro token, use o fluxo já aprovado no ambiente. /api/auth/token é rotina de plantão, não login JWT de aplicação.
3. Preencha loginUsuario e senhaUsuario e execute 02 Login individual Manager. O script guarda chaveToken em usuarioToken; não use tokenAcesso como JWT individual.
4. Configure codgSistema, codgAgencia, códigos externos e vínculos do Manager. codgCidadeOrigem/codgCidadeDestino do payload recebem codgVinculoCidadeSistema, não codgCidade.
5. Defina data futura, pesquise e selecione manualmente codigoViagem e assento. O exemplo de compra é direto, com um passageiro. Para conexões/ida e volta, informe todos os trechos efetivos e poltronas de conexão.
6. Preencha passageiro, sexo conforme cadastro, email e chaveCompra única de 8 a 64 caracteres.
7. Para uma operação com efeito, defina permitirOperacoesComEfeito=true e acaoPermitida com a ação exata. Execute individualmente. A ação é limpa depois da resposta.

Ações aceitas: reservar, emitir, cancelarReserva, cancelarBilhete, adicionarNota, registrarRecebimento. reservar faz booking e checkout, podendo cobrar. emitir é uma alternativa para booking existente; não a execute para repetir uma compra já reservada. preApproved depende da habilitação da conta. PIX/cartão precisam seguir o contrato do Hub e não são tokenizados pela collection.

O bloqueio usa pm.execution.skipRequest() em pre-request. Documentação oficial: https://learning.postman.com/docs/tests-and-scripts/write-scripts/postman-sandbox-reference/pm-execution/ . Use uma versão com suporte à API. Não execute todas as pastas no Runner como se fossem um único fluxo automático.

## Resultados e recuperação

HTTP 200 pode conter success=false ou requerConferencia=true. Os testes positivos marcam essas respostas para revisão; não repita checkout para resolver timeout.

Antes de reservar/emitir, o script salva payloadRecuperacao com os metadados e chave originais, sem campos de cartão/comprador e sem recebimento manual adicional. A requisição 17 usa essa snapshot e nunca cria novo booking ou checkout. Se outra tentativa substituir a snapshot, restaure os dados da compra anterior antes de recuperá-la. Referência ausente retorna 409 e exige conferência no fornecedor. A verificação por referência não substitui idempotência de checkout e não garante exclusão entre várias instâncias.

Confirmada 1 exige compra paid e todos os bilhetes emitted com número. Compra pendente fica 0. Cancelada 2 exige compra e todos os bilhetes canceled. Cancelamento parcial exige conferência operacional, pois o Manager atual impede editar componentes de reservas confirmadas. Não há estorno automático.

Registrar recebimento apenas concilia uma transação existente; exige usuário interno e chave própria, sem cobrar cartão ou confirmar PIX. Conserve a chave ao repetir o mesmo registro.

## Variáveis

| Variável | Inicial | Uso |
| --- | --- | --- |
| `baseUrl` | http://localhost:8088 | URL sem barra final; inclua o contexto do WAR. |
| `prefix` | /v1/rodoviario | Prefixo rodoviario. |
| `appToken` | vazio | JWT aceito pelo ConfApi, sem Bearer. |
| `usuarioToken` | vazio | JWT individual retornado em chaveToken. |
| `loginApp` | vazio | Login para renovacao opcional. |
| `senhaApp` | vazio | Senha local para renovacao opcional. |
| `loginUsuario` | vazio | Login individual do Manager. |
| `senhaUsuario` | vazio | Senha individual local. |
| `sistema` | QueroPassagem | Nome do fornecedor no Hub. |
| `codgSistema` | vazio | ID do sistema no Manager. |
| `codgAgencia` | vazio | ID da agencia autorizada. |
| `origemCodigo` | vazio | Codigo externo CIT_n ou ROD_n. |
| `destinoCodigo` | vazio | Codigo externo CIT_n ou ROD_n. |
| `codgVinculoOrigem` | vazio | codgVinculoCidadeSistema da origem. |
| `codgVinculoDestino` | vazio | codgVinculoCidadeSistema do destino. |
| `buscaDestino` | São Paulo | Filtro por nome; limpe para listar todos e pagine. |
| `dataViagem` | vazio | Data futura YYYY-MM-DD. |
| `codigoViagem` | vazio | codigoFornecedor selecionado na pesquisa. |
| `assento` | vazio | Poltrona disponivel escolhida manualmente. |
| `codigoViacao` | vazio | Codigo externo da viacao. |
| `nomePassageiro` | Passageiro | Nome de homologacao. |
| `sobrenomePassageiro` | Teste | Sobrenome. |
| `cpfPassageiro` | vazio | CPF de homologacao com 11 digitos. |
| `dataNascimento` | 2000-01-01 | Nascimento YYYY-MM-DD. |
| `sexoPassageiro` | vazio | Codigo conforme cadastro do Manager. |
| `emailCompra` | vazio | Email da compra. |
| `chaveCompra` | vazio | Chave unica de 8 a 64 caracteres; preservar na recuperacao. |
| `codgReservaRodoviario` | vazio | ID local retornado em reserva.reserva. |
| `codigoCompra` | vazio | Codigo externo da compra. |
| `codigoReservaTemporaria` | vazio | Identificador do booking. |
| `codigoPassageiro` | vazio | ID externo do passageiro. |
| `codgRodoviarioTrecho` | vazio | ID local do trecho. |
| `payloadRecuperacao` | vazio | Snapshot de recuperacao sem campos de cartao. |
| `permitirOperacoesComEfeito` | false | Habilitar explicitamente chamadas com efeito. |
| `acaoPermitida` | vazio | Uma acao por vez; limpa apos a resposta. |
| `motivoCancelamento` | Solicitacao de teste em homologacao | Motivo do cancelamento. |
| `notaHistorico` | Teste rodoviario no Postman | Observacao do historico. |
| `chaveRecebimento` | vazio | Chave propria de 8 a 50 caracteres. |
| `codgFormaPagto` | vazio | Forma de pagamento do Manager. |
| `valorRecebimento` | vazio | Valor ja conciliado com ponto decimal. |
| `dataRecebimento` | vazio | Data YYYY-MM-DD nao futura. |
| `codgTransacao` | vazio | Identificador da transacao ja conciliada. |

## Validação offline da collection

Execute `node docs/postman/validate-postman.cjs` a partir da raiz do repositório. O script usa somente módulos nativos do Node e fixtures, sem chamadas reais.

## Testes negativos e diagnóstico

- Sem Bearer: 401 ou 403, conforme o filtro de segurança implantado.
- Sem X-Usuario-Token, mantendo appToken válido: 401.
- Recurso desconhecido/JSON malformado: 400.
- Código de outra compra: 200 com success=false e requerConferencia=true no service atual.
- Fora de agência/unidade: faça teste adicional com outro JWT de homologação; espere 403 antes de booking/checkout.
- Sem resposta nem status HTTP: abra o Console do Postman. A versão anterior pulava a chamada quando appToken estava vazio no environment. Reimporte a collection atualizada; mantenha o environment já preenchido. Agora consultas sem token são enviadas para receber HTTP 401/403. A validação usa os valores efetivos do Postman (pm.variables.get), respeitando a prioridade dos escopos; um valor vazio no environment ainda sobrepõe um token global.
- Mensagem REQUISICAO NAO ENVIADA no Console: confira as variáveis indicadas ou a ação habilitada; há também um teste de configuração com falha.
- Após reiniciar o ConfApi com o código atualizado, procure Rodoviario entrada/saida nos logs INFO. A saída inclui status e duracaoMs; o header X-Rodoviario-Request-Id relaciona a resposta aos logs de integração HUB/MANAGER. Essas linhas não imprimem query strings, tokens ou corpos. Etapa autenticacao sem envio indica espera no ConfApp; etapa envio indica espera no Hub/Manager.
- Sem log de entrada após clicar Send: confirme que a requisição foi enviada no Console, a porta 8088, o contexto do WAR e a versão em execução. Teste 31 sem Bearer deve receber 401/403 mesmo antes do controller.
- 404 geral: confira contexto do WAR, prefixo e versões implantadas.
- 502/503/504: confira servico e codigo na resposta, URLs e credenciais internas. Havendo efeito incerto, recupere por consulta.

Nenhuma chamada real é executada na geração deste pacote. JSONs e scripts são verificados offline; credenciais, disponibilidade, pagamentos e estados precisam de homologação. Tokens e senhas começam vazios. Não exporte dados pessoais, senhas, tokens ou snapshots preenchidas para o repositório ou terceiros.

## Reserva interrompida antes do backend

Se o Console mostrar `REQUISICAO NAO ENVIADA`, nao existe uma chamada correspondente no ConfApi. Para a requisicao 14, configure `permitirOperacoesComEfeito=true` e `acaoPermitida=reservar` no environment selecionado, sem aspas. A collection identifica separadamente qual controle falta e aceita espacos externos e o booleano true. A acao continua sendo limpa apos a resposta.

Para erros que chegarem ao servidor, procure `Rodoviario erro` nos logs. A linha inclui requestId, etapa, servico, status, codigo, tipo, requerConferencia, motivo local e origem (classe/metodo/linha). Falhas parciais tambem sao registradas. Corpos, tokens e mensagens arbitrarias recebidas de terceiros nao sao impressos. O header `X-Rodoviario-Request-Id` permite relacionar a resposta aos logs.

## Alternativa: envio manual da reserva

Se a requisicao importada continuar mostrando o aviso antigo de habilitacao, importe apenas `confapi-rodoviario-reserva-manual.postman_collection.json`. Abra a nova collection **ConfApi Rodoviario - Reserva manual**, selecione o environment ja preenchido e use sua unica requisicao. Esta alternativa nao depende de `permitirOperacoesComEfeito` nem de `acaoPermitida`. Body, Bearer appToken, X-Usuario-Token, validacao de campos e snapshot para recuperacao continuam iguais. A collection principal conserva os controles anteriores.

Para corrigir diretamente a requisicao ja aberta, substitua todo o conteudo de **Scripts > Pre-request** pelo arquivo `reservar-manual.pre-request.js` e salve a requisicao. Editar arquivos do repositorio nao atualiza automaticamente uma requisicao ja importada no Postman.

O envio manual executa booking e checkout ao clicar Send. Execute individualmente, sem Runner em lote. Se uma tentativa anterior chegou ao fornecedor e ficou incerta, consulte/sincronize a compra antes de enviar outra reserva.
